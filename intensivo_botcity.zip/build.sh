#!/bin/bash

zip -r "intensivo_botcity.zip" * -x "intensivo_botcity.zip"